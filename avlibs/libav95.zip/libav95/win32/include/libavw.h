#define LIBAVW_AVBUILDINFO  "Windows x86 (LibAV 9.5 Official Build)"
