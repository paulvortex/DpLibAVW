#define LIBAVW_AVBUILDINFO  "Windows x64 (LibAV 9.5 Official Build)"
