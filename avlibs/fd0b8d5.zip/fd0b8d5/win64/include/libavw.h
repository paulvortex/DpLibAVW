#define LIBAVW_AVBUILDINFO  "Windows x64 Shared (Git fd0b8d5)"

