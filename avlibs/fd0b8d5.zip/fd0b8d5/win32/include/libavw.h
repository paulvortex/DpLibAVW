#define LIBAVW_AVBUILDINFO  "Windows x86 Shared (Git fd0b8d5)"
